package Array;

public class SearchElement {
    public boolean finded(int []a,boolean b,int c){
        for (int i = 0; i < a.length-1; i++) {
            if(a[i]==c){
                b=true;
            }

        }
        if(b==true){
            System.out.println(a+" is present in the array");
        }
        else{
            System.out.println(a+" is not present ");
        }
        return b;
    }


    public static void main(String[] args) {
        int []arr={1,2,3,5,1,2,7,8,9};
        boolean num=false;
        int a=2;
        
        
    }
}
