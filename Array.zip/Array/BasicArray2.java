package Array;

public class BasicArray2 {
    public static void main(String[] args) {
        int [] arr={1,2,3,4,5};
        System.out.println(arr.length);
        int j=0;
        while (j<arr.length) {
            System.out.println(arr[j]);
            j++;
        }
    }
}
